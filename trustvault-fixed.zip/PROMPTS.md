
# AI Usage Log

## Prompt 1
Asked AI to help create a Flask document-sharing application.

## AI Error or Limitation
The initial implementation did not include all security protections.

## My Correction
Reviewed the code and identified additional security requirements,
including CSRF protection and restricted audit log access.

## Testing
Record the tests performed and their results here.

## Security fixes (review round)

Problems found in the first version, and how each was fixed:

- Templates were nested in `templates/templates/...` and the stylesheet was
  under `templates/static/`, so the dashboard and audit pages crashed and CSS
  never loaded. Moved to `templates/` and `static/`.
- `login.html` asked for an email, which the server ignored, so login could
  never succeed. Now asks for username and password.
- Missing documents returned 404 but other users' documents returned 403,
  revealing which ids exist. Both now return the same 404.
- Users with edit permission could share (including granting edit) and
  revoke. Now owner-only; edit means "can replace the file".
- `/audit` showed every user's activity to everyone. Now scoped.
- No CSRF protection; logout was a GET. Added tokens; logout is POST.
- Audit rows were committed separately from the change, and refused
  share/revoke requests were not logged. Now one transaction, and every
  refusal writes a `denied` row.
- A random `SECRET_KEY` per process logged users out at random under
  gunicorn. Now taken from the environment or one persisted file.
- `debug=True` was hard-coded. Now only with `FLASK_DEBUG=1`.

## Testing

`pytest`: 15 tests. Each access check was verified by putting the bug back
(e.g. letting editors share, returning 403 instead of 404, removing the
CSRF check, unscoping the audit query) and confirming a test fails.

## Round 2: features ported from the TypeScript TrustVault

Added: encryption at rest, version history, time-limited grants, trash,
document activity, hash-chained audit log, admin console with alerts,
account deactivation, session invalidation, login throttling, password
change, demo seed data, mutation check.

Where the AI got it wrong:

- It first checked "is this account active?" in two places (the session
  loader and the authorisation SQL). The mutation check showed that
  removing either one left all tests green, because deactivation also
  invalidates sessions. Fixed by keeping one place (`load_user`) and adding
  a test that sets `active = 0` directly.
- A test for audit tampering edited the row that the same test had just
  deleted, so it tested nothing. Caught because it failed; fixed to edit a
  row that still exists.
- Default Python sqlite3 transactions start lazily, so two workers could
  read the same audit head and fork the chain. Fixed with explicit
  `BEGIN IMMEDIATE` in `tx()`.
