"""Sessions, CSRF, uploads, encryption, audit chain, admin."""
import io
import os
import sqlite3

import pytest

import audit
from app import create_app
from conftest import PASSWORD, User, uid
from database import connect
from storage import Storage


def test_all_pages_render(users, db):
    alice, root = users("alice", "root")
    doc = alice.upload()
    db.execute("UPDATE users SET role = 'admin' WHERE username = 'root'")
    root.login()
    for url in ["/", "/dashboard", "/audit", "/account", f"/documents/{doc}",
                f"/documents/{doc}/activity"]:
        assert alice.get(url).status_code == 200, url
    for url in ["/admin", "/admin/audit", "/admin/audit?verify=1"]:
        assert root.get(url).status_code == 200, url
    anon = alice.app.test_client()
    for url in ["/", "/login", "/register", "/static/style.css"]:
        assert anon.get(url).status_code == 200, url


def test_csrf_required(users):
    (alice,) = users("alice")
    doc = alice.upload()
    assert alice.client.post(f"/documents/{doc}/delete").status_code == 400
    assert alice.post(f"/documents/{doc}/delete", {"csrf_token": "x"}).status_code == 400
    assert alice.get(f"/documents/{doc}").status_code == 200


def test_unknown_form_fields_are_rejected(users):
    (alice,) = users("alice")
    doc = alice.upload()
    assert alice.post(f"/documents/{doc}/share",
                      {"username": "x", "owner_id": "1"}).status_code == 400


def test_logout_requires_post(users):
    (alice,) = users("alice")
    assert alice.get("/logout").status_code == 405
    alice.post("/logout")
    assert alice.get("/dashboard").status_code == 302


def test_upload_content_must_match_extension(users, db):
    (alice,) = users("alice")
    assert alice.upload(name="evil.html", content=b"<script>") is None
    assert alice.upload(name="fake.pdf", content=b"<script>alert(1)</script>") is None
    assert alice.upload(name="bin.txt", content=b"\xff\xfe\x00") is None
    assert alice.upload(name="empty.txt", content=b"") is None
    assert alice.upload(name="real.pdf", content=b"%PDF-1.7 ...") is not None
    assert db.execute("SELECT COUNT(*) FROM documents").fetchone()[0] == 1


def test_files_are_encrypted_at_rest(app, users):
    (alice,) = users("alice")
    doc = alice.upload(content=b"TOP SECRET PAYLOAD")
    folder = app.config["UPLOAD_FOLDER"]
    for name in os.listdir(folder):
        with open(os.path.join(folder, name), "rb") as f:
            assert b"TOP SECRET" not in f.read()
    assert alice.get(f"/documents/{doc}/download").data == b"TOP SECRET PAYLOAD"


def test_tampered_or_swapped_ciphertext_fails(tmp_path):
    store = Storage(str(tmp_path), os.urandom(32))
    a, b = store.put(b"aaaa"), store.put(b"bbbb")
    with pytest.raises(Exception):  # key of a, file of b
        store.get(b["stored_name"], a["wrapped_key"])
    path = tmp_path / a["stored_name"]
    data = bytearray(path.read_bytes())
    data[-1] ^= 1
    path.write_bytes(bytes(data))
    with pytest.raises(Exception):
        store.get(a["stored_name"], a["wrapped_key"])
    with pytest.raises(Exception):
        Storage(str(tmp_path), os.urandom(32)).get(b["stored_name"], b["wrapped_key"])


def test_audit_chain_detects_edits_and_truncation(app, users, db):
    alice, bob = users("alice", "bob")
    doc = alice.upload()
    alice.share(doc, "bob")
    key = app.config["AUDIT_KEY"]
    assert audit.verify(db, key)["ok"]
    head = app.config["HEADS"][-1]
    assert audit.verify(db, key, head["seq"], head["hash"])["ok"]

    db.execute("DROP TRIGGER audit_logs_no_update")
    db.execute("DROP TRIGGER audit_logs_no_delete")
    db.execute("DELETE FROM audit_logs WHERE seq = (SELECT MAX(seq) FROM audit_logs)")
    assert audit.verify(db, key)["ok"]  # truncation alone keeps the chain valid...
    result = audit.verify(db, key, head["seq"], head["hash"])
    assert not result["ok"] and "deleted" in result["reason"]  # ...the head record catches it

    db.execute("UPDATE audit_logs SET details = 'nothing happened' WHERE action = 'upload'")
    result = audit.verify(db, key)
    assert not result["ok"] and result["first_bad_seq"] is not None


def test_audit_log_is_append_only(db, users):
    users("alice")
    with pytest.raises(sqlite3.DatabaseError):
        db.execute("UPDATE audit_logs SET action = 'x'")
    with pytest.raises(sqlite3.DatabaseError):
        db.execute("DELETE FROM audit_logs")


def test_state_change_and_audit_row_are_atomic(app, users, db, monkeypatch):
    alice, bob = users("alice", "bob")
    doc = alice.upload()
    real = audit.append

    def failing(*a, **kw):
        if kw.get("action") == "share":
            raise RuntimeError("audit write failed")
        return real(*a, **kw)

    monkeypatch.setattr(audit, "append", failing)
    app.testing = False
    app.config["PROPAGATE_EXCEPTIONS"] = False
    assert alice.share(doc, "bob").status_code == 500
    assert db.execute("SELECT COUNT(*) FROM permissions").fetchone()[0] == 0


def test_admin_has_no_document_access(users, db):
    alice, root = users("alice", "root")
    doc = alice.upload()
    db.execute("UPDATE users SET role = 'admin' WHERE username = 'root'")
    root.login()
    assert root.get(f"/documents/{doc}/download").status_code == 404
    assert root.get(f"/documents/{doc}").status_code == 404


def test_non_admin_cannot_reach_admin_pages(users, db):
    (alice,) = users("alice")
    for url in ["/admin", "/admin/audit"]:
        assert alice.get(url).status_code == 404
    assert alice.post(f"/admin/users/{uid(db, 'alice')}", {"role": "admin"}).status_code == 404
    assert db.execute("SELECT role FROM users").fetchone()[0] == "user"
    assert db.execute("SELECT COUNT(*) FROM audit_logs WHERE action = 'admin_access' "
                      "AND outcome = 'denied'").fetchone()[0] == 3


def test_deactivation_ends_sessions_immediately(app, users, db):
    alice, bob, root = users("alice", "bob", "root")
    doc = alice.upload()
    alice.share(doc, "bob")
    db.execute("UPDATE users SET role = 'admin' WHERE username = 'root'")
    root.login()
    assert bob.get(f"/documents/{doc}").status_code == 200
    root.post(f"/admin/users/{uid(db, 'bob')}", {"active": "0"})
    assert bob.get(f"/documents/{doc}").status_code == 302  # logged out
    assert bob.login().headers.get("Location", "").endswith("/dashboard") is False
    root.post(f"/admin/users/{uid(db, 'bob')}", {"active": "1"})
    bob.login()
    assert bob.get(f"/documents/{doc}").status_code == 200


def test_inactive_account_has_no_session_even_without_version_bump(users, db):
    alice, bob = users("alice", "bob")
    doc = alice.upload()
    alice.share(doc, "bob")
    db.execute("UPDATE users SET active = 0 WHERE username = 'bob'")  # e.g. done in SQL
    assert bob.get(f"/documents/{doc}").status_code == 302


def test_admin_cannot_change_self(users, db):
    (root,) = users("root")
    db.execute("UPDATE users SET role = 'admin' WHERE username = 'root'")
    root.login()
    root.post(f"/admin/users/{uid(db, 'root')}", {"active": "0"})
    assert db.execute("SELECT active FROM users").fetchone()[0] == 1


def test_password_change_signs_out_other_sessions(app, users):
    (alice,) = users("alice")
    other = User(app, "alice", register=False)
    assert other.get("/dashboard").status_code == 200
    alice.post("/account", {"current_password": PASSWORD, "new_password": "brand-new-pw"})
    assert alice.get("/dashboard").status_code == 200
    assert other.get("/dashboard").status_code == 302
    assert other.login("brand-new-pw").status_code == 302


def test_login_is_throttled(app, users):
    (alice,) = users("alice")
    attacker = app.test_client()
    probe = User.__new__(User)
    probe.client, probe.username = attacker, "alice"
    for _ in range(5):
        probe.login("wrong-password")
    r = probe.login(PASSWORD)
    assert r.status_code == 429


def test_alerts_flag_probing(app, users, db):
    alice, mallory, root = users("alice", "mallory", "root")
    doc = alice.upload()
    for _ in range(5):
        mallory.get(f"/documents/{doc}/download")
    db.execute("UPDATE users SET role = 'admin' WHERE username = 'root'")
    root.login()
    page = root.get("/admin").get_data(as_text=True)
    assert "access_probing" in page and "mallory" in page


def test_alerts_flag_broken_chain(app, users, db):
    (root,) = users("root")
    db.execute("UPDATE users SET role = 'admin' WHERE username = 'root'")
    root.login()
    db.execute("DROP TRIGGER audit_logs_no_update")
    db.execute("UPDATE audit_logs SET details = 'x' WHERE seq = 1")
    assert "audit_tamper" in root.get("/admin").get_data(as_text=True)


def test_keys_shared_across_workers_and_required_in_production(tmp_path, monkeypatch):
    monkeypatch.setenv("TRUSTVAULT_DATA_DIR", str(tmp_path))
    for k in ("SECRET_KEY", "TRUSTVAULT_MASTER_KEY", "TRUSTVAULT_AUDIT_KEY", "TRUSTVAULT_ENV"):
        monkeypatch.delenv(k, raising=False)
    a, b = create_app(), create_app()
    assert a.secret_key == b.secret_key
    assert a.config["MASTER_KEY"] == b.config["MASTER_KEY"] != a.config["AUDIT_KEY"]

    monkeypatch.setenv("TRUSTVAULT_ENV", "production")
    monkeypatch.setenv("TRUSTVAULT_DATA_DIR", str(tmp_path / "prod"))
    with pytest.raises(RuntimeError):
        create_app()


def test_seed_demo_story(app, monkeypatch):
    from seed import seed
    seed(app)
    vera = User(app, "vera", register=False)
    vera.login("Viewer-Demo-2026!")
    db = connect(app.config["DATABASE"])
    victor_letter = db.execute(
        "SELECT id FROM documents WHERE title = 'Salary letter - Victor'").fetchone()[0]
    own_letter = db.execute(
        "SELECT id FROM documents WHERE title = 'Salary letter - Vera'").fetchone()[0]
    assert vera.get(f"/documents/{own_letter}/download").status_code == 200
    assert vera.get(f"/documents/{victor_letter}/download").status_code == 404
    assert audit.verify(db, app.config["AUDIT_KEY"])["ok"]
