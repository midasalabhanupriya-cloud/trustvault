import io
import os
import re
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app  # noqa: E402
from database import connect  # noqa: E402

PASSWORD = "password123"


@pytest.fixture
def app(tmp_path, monkeypatch):
    monkeypatch.setenv("TRUSTVAULT_DATA_DIR", str(tmp_path))
    monkeypatch.delenv("TRUSTVAULT_ENV", raising=False)
    heads = []
    application = create_app({
        "TESTING": True,
        "AUDIT_HEAD_SINK": heads.append,
    })
    application.config["HEADS"] = heads
    return application


@pytest.fixture
def db(app):
    conn = connect(app.config["DATABASE"])
    yield conn
    conn.close()


class User:
    """A logged-in browser session for one user."""

    def __init__(self, app, username, register=True):
        self.app = app
        self.client = app.test_client()
        self.username = username
        if register:
            self.post("/register", {"username": username, "password": PASSWORD})
        self.login()

    def login(self, password=PASSWORD):
        return self.post("/login", {"username": self.username, "password": password})

    def token(self):
        html = self.client.get("/login").get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([^"]+)"', html).group(1)

    def post(self, url, data=None, **kw):
        data = dict(data or {})
        data.setdefault("csrf_token", self.token())
        return self.client.post(url, data=data, **kw)

    def get(self, url):
        return self.client.get(url)

    def upload(self, name="doc.txt", content=b"secret", title=None):
        data = {"file": (io.BytesIO(content), name)}
        if title:
            data["title"] = title
        r = self.post("/upload", data, content_type="multipart/form-data")
        m = re.search(r"/documents/(\d+)$", r.headers.get("Location", ""))
        return int(m.group(1)) if m else None

    def new_version(self, doc, content=b"v2", name="v2.txt"):
        return self.post(f"/documents/{doc}/versions",
                         {"file": (io.BytesIO(content), name)},
                         content_type="multipart/form-data")

    def share(self, doc, username, permission="read", expires_days=""):
        return self.post(f"/documents/{doc}/share",
                         {"username": username, "permission": permission,
                          "expires_days": expires_days})


@pytest.fixture
def users(app):
    def make(*names):
        return [User(app, n) for n in names]
    return make


def uid(db, username):
    return db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()[0]


