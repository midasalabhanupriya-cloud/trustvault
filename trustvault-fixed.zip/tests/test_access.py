"""Who can reach which document, and what the response reveals."""
import io

import pytest

from conftest import uid


def doc_routes(doc, other_id=1, version_id=1):
    """Every route that takes a document id. test_route_list_is_complete
    fails if a new route is added without being listed here."""
    return [
        ("get", f"/documents/{doc}", "view"),
        ("get", f"/documents/{doc}/download", "download"),
        ("get", f"/documents/{doc}/versions/{version_id}/download", "download_version"),
        ("post", f"/documents/{doc}/versions", "upload_version"),
        ("post", f"/documents/{doc}/edit", "update_metadata"),
        ("post", f"/documents/{doc}/share", "share"),
        ("post", f"/documents/{doc}/revoke/{other_id}", "revoke"),
        ("get", f"/documents/{doc}/activity", "view_activity"),
        ("post", f"/documents/{doc}/delete", "delete"),
        ("post", f"/documents/{doc}/restore", "restore"),
        ("post", f"/documents/{doc}/purge", "purge"),
    ]


def call(user, method, url):
    return user.get(url) if method == "get" else user.post(url)


def test_route_list_is_complete(app):
    listed = {url.replace("/7", "/<document_id>", 1) for _, url, _ in doc_routes(7)}
    actual = set()
    for rule in app.url_map.iter_rules():
        if "document_id" in rule.arguments:
            path = rule.rule.replace("<int:document_id>", "<document_id>")
            path = path.replace("<int:version_id>", "1").replace("<int:target_id>", "1")
            actual.add(path)
    assert actual == listed


def test_stranger_gets_same_404_as_missing_document(users, db):
    alice, mallory = users("alice", "mallory")
    doc = alice.upload()
    for (method, url, _), (_, missing, _) in zip(doc_routes(doc), doc_routes(9999)):
        real = call(mallory, method, url)
        gone = call(mallory, method, missing)
        assert real.status_code == gone.status_code == 404, url
        assert real.data == gone.data, url
    denied = db.execute("SELECT COUNT(*) FROM audit_logs WHERE outcome = 'denied' "
                        "AND user_id = ?", (uid(db, "mallory"),)).fetchone()[0]
    assert denied == 2 * len(doc_routes(doc))


@pytest.mark.parametrize("level,allowed", [
    ("read", {"view", "download"}),
    ("edit", {"view", "download", "download_version", "upload_version", "update_metadata"}),
])
def test_permission_matrix(users, db, level, allowed):
    alice, bob = users("alice", "bob")
    doc = alice.upload()
    alice.share(doc, "bob", level)
    version = db.execute("SELECT id FROM document_versions WHERE document_id = ?",
                         (doc,)).fetchone()[0]
    for method, url, action in doc_routes(doc, uid(db, "alice"), version):
        if action in ("restore", "purge"):
            continue  # live document; see test_trash
        status = call(bob, method, url).status_code
        if action in allowed:
            assert status in (200, 302), (action, status)
        else:
            assert status == 403, (action, status)


def test_editor_cannot_share_or_revoke(users, db):
    alice, bob, carol = users("alice", "bob", "carol")
    doc = alice.upload()
    alice.share(doc, "bob", "edit")
    alice.share(doc, "carol", "read")
    assert bob.share(doc, "carol", "edit").status_code == 403
    assert bob.post(f"/documents/{doc}/revoke/{uid(db, 'carol')}").status_code == 403
    assert db.execute("SELECT permission FROM permissions WHERE user_id = ?",
                      (uid(db, "carol"),)).fetchone()[0] == "read"


def test_version_id_is_bound_to_document(users, db):
    alice, bob = users("alice", "bob")
    shared = alice.upload(content=b"shared")
    private = alice.upload(content=b"private")
    alice.share(shared, "bob", "edit")
    private_version = db.execute(
        "SELECT id FROM document_versions WHERE document_id = ?", (private,)).fetchone()[0]
    r = bob.get(f"/documents/{shared}/versions/{private_version}/download")
    assert r.status_code == 404 and b"private" not in r.data


def test_revoke_takes_effect_on_next_request_and_is_bound(users, db):
    alice, bob, mallory = users("alice", "bob", "mallory")
    doc1, doc2 = alice.upload(), alice.upload()
    alice.share(doc1, "bob")
    alice.share(doc2, "bob")
    mallory.upload()
    assert mallory.post(f"/documents/{doc1}/revoke/{uid(db, 'bob')}").status_code == 404
    assert bob.get(f"/documents/{doc1}/download").status_code == 200
    alice.post(f"/documents/{doc1}/revoke/{uid(db, 'bob')}")
    assert bob.get(f"/documents/{doc1}/download").status_code == 404
    assert bob.get(f"/documents/{doc2}/download").status_code == 200


def test_expired_grant_gives_no_access(users, db):
    alice, bob = users("alice", "bob")
    doc = alice.upload()
    alice.share(doc, "bob", "read", expires_days="3")
    assert bob.get(f"/documents/{doc}").status_code == 200
    with db:
        pass
    db.execute("UPDATE permissions SET expires_at = '2000-01-01T00:00:00+00:00'")
    assert bob.get(f"/documents/{doc}").status_code == 404
    assert "doc.txt" not in bob.get("/dashboard").get_data(as_text=True)
    assert "expired" in alice.get(f"/documents/{doc}").get_data(as_text=True)


def test_bad_expiry_is_rejected(users, db):
    alice, bob = users("alice", "bob")
    doc = alice.upload()
    for bad in ("0", "366", "-1", "abc"):
        alice.share(doc, "bob", "read", expires_days=bad)
    assert db.execute("SELECT COUNT(*) FROM permissions").fetchone()[0] == 0


def test_trash(app, users, db):
    alice, bob = users("alice", "bob")
    doc = alice.upload(content=b"to be deleted")
    alice.share(doc, "bob")
    assert alice.post(f"/documents/{doc}/restore").status_code == 409  # not in trash
    assert bob.post(f"/documents/{doc}/restore").status_code == 403

    alice.post(f"/documents/{doc}/delete")
    assert bob.get(f"/documents/{doc}").status_code == 404
    assert alice.get(f"/documents/{doc}/download").status_code == 404
    assert bob.post(f"/documents/{doc}/restore").status_code == 404  # trash is invisible
    assert "Trash" in alice.get("/dashboard").get_data(as_text=True)

    alice.post(f"/documents/{doc}/restore")
    assert bob.get(f"/documents/{doc}/download").data == b"to be deleted"

    import os
    blob_dir = app.config["UPLOAD_FOLDER"]
    assert os.listdir(blob_dir)
    alice.post(f"/documents/{doc}/delete")
    alice.post(f"/documents/{doc}/purge")
    assert os.listdir(blob_dir) == []
    assert alice.post(f"/documents/{doc}/restore").status_code == 404
    assert db.execute("SELECT COUNT(*) FROM audit_logs WHERE action = 'purge'").fetchone()[0] == 1


def test_versions(users, db):
    alice, bob = users("alice", "bob")
    doc = alice.upload(content=b"v1")
    alice.share(doc, "bob", "edit")
    bob.new_version(doc, b"v2")
    assert alice.get(f"/documents/{doc}/download").data == b"v2"
    v1 = db.execute("SELECT id FROM document_versions WHERE document_id = ? AND version_no = 1",
                    (doc,)).fetchone()[0]
    assert bob.get(f"/documents/{doc}/versions/{v1}/download").data == b"v1"


def test_metadata_edit(users, db):
    alice, bob = users("alice", "bob")
    doc = alice.upload(title="Old title")
    alice.share(doc, "bob", "edit")
    bob.post(f"/documents/{doc}/edit", {"title": "New title", "description": "d"})
    assert "New title" in alice.get(f"/documents/{doc}").get_data(as_text=True)


def test_owner_sees_refusals_in_document_activity(users):
    alice, mallory = users("alice", "mallory")
    doc = alice.upload()
    mallory.get(f"/documents/{doc}/download")
    page = alice.get(f"/documents/{doc}/activity").get_data(as_text=True)
    assert "mallory" in page and "denied" in page


def test_my_activity_shows_only_my_rows(users):
    alice, mallory = users("alice", "mallory")
    alice.upload(name="alice-private.txt")
    page = mallory.get("/audit").get_data(as_text=True)
    assert "alice-private.txt" not in page and "alice" not in page
