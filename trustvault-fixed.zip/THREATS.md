# TrustVault Threat Model

## Protected assets

User accounts, uploaded documents (all versions), sharing permissions,
and the audit log.

## Threats and mitigations

| Threat | Mitigation | Test |
|---|---|---|
| Reading someone else's document | One check, `gate()` in `authz.py`, before every document route | `test_stranger_gets_same_404_as_missing_document`, `test_permission_matrix` |
| A new route without a check | Every route with a document id must be listed in `doc_routes()` | `test_route_list_is_complete` |
| Probing which document ids exist | No access -> 404, byte-identical to a missing document | `test_stranger_gets_same_404_as_missing_document` |
| Editor escalates (re-shares, grants edit) | Share/revoke are owner-only | `test_editor_cannot_share_or_revoke` |
| Fetching another document's version via a shared one | Version id bound with `AND document_id = ?` | `test_version_id_is_bound_to_document` |
| Revoking grants on another owner's document | Owner-level gate plus `WHERE document_id = ? AND user_id = ?` | `test_revoke_takes_effect_on_next_request_and_is_bound` |
| Access outlives revocation or expiry | No permission caching; expiry compared on every request | `test_revoke_takes_effect_on_next_request_and_is_bound`, `test_expired_grant_gives_no_access` |
| Trashed document still reachable by grantees | Trash is visible only to the owner, only for restore/purge | `test_trash` |
| Stolen disk or backup | AES-256-GCM per version, keys wrapped by a master key held outside the data | `test_files_are_encrypted_at_rest`, `test_tampered_or_swapped_ciphertext_fails` |
| Admin reads documents | The admin role gives no document access | `test_admin_has_no_document_access` |
| Non-admin reaches admin pages | `admin_required`; 404 plus a denied audit row | `test_non_admin_cannot_reach_admin_pages` |
| Deactivated user keeps working | Account state checked on every request; sessions versioned | `test_deactivation_ends_sessions_immediately`, `test_inactive_account_has_no_session_even_without_version_bump` |
| Stolen session after password change | Password change bumps the session version | `test_password_change_signs_out_other_sessions` |
| Password guessing | 5 failures per username or 20 per IP in 15 minutes -> throttled; alerts for spraying | `test_login_is_throttled` |
| CSRF | Per-session token on every POST; logout is POST; SameSite=Lax | `test_csrf_required`, `test_logout_requires_post` |
| Mass-assignment / unexpected fields | Unknown form fields are a 400 | `test_unknown_form_fields_are_rejected` |
| Malicious upload (HTML/script renamed) | Extension allow-list, content signature check, served as attachment with `nosniff` | `test_upload_content_must_match_extension` |
| Action without an audit record | Audit row written in the same transaction | `test_state_change_and_audit_row_are_atomic` |
| Editing or deleting audit rows | Triggers block UPDATE/DELETE; HMAC chain detects edits; head printed to platform log detects truncation | `test_audit_log_is_append_only`, `test_audit_chain_detects_edits_and_truncation` |
| Audit tampering goes unnoticed | Chain verified on every admin page load; critical alert | `test_alerts_flag_broken_chain` |
| Insider probing / bulk exfiltration | Alerts from the audit log | `test_alerts_flag_probing` |
| Users see other users' activity | "My activity" shows only your rows; document activity is owner-only | `test_my_activity_shows_only_my_rows`, `test_owner_sees_refusals_in_document_activity` |
| Weak or shared secrets in production | Production refuses to start without keys; master and audit keys must differ | `test_keys_shared_across_workers_and_required_in_production` |
| Audit chain forks under concurrency | Every write uses `BEGIN IMMEDIATE` | Manual: 80 concurrent requests on 4 gunicorn workers, chain verified intact |
| Clickjacking / script injection | CSP `script-src 'none'`, `frame-ancestors 'none'`, Jinja autoescaping | - |
| SQL injection | Parameterised queries only | - |

Every check in the table was also verified by removing it and confirming a
test fails: see `scripts/mutation_check.py` and `docs/mutation-results.txt`.

## Accepted risks / known limitations

- Someone with both the database and the audit key (full control of the
  server) can rewrite history; the externally logged chain head limits this.
- Registration reveals whether a username is taken.
- Login throttling can be used to lock a known username out for 15 minutes.
- Uploaded files are not virus-scanned.
- SQLite means one server only.
- No two-factor authentication.
