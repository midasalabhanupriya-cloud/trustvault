# Instructions for AI assistants working on TrustVault (Flask)

1. **Authorisation lives in one place**: `REQUIRED_LEVEL` / `ACCESS_LEVEL_SQL`
   / `gate()` in `authz.py`. Do not write a second "who can see this" check,
   and no "defence in depth" duplicates: a duplicate means removing either
   check leaves the tests green.
2. **New document route?** Add its action to `REQUIRED_LEVEL`, call `gate()`
   first, bind every child id with `AND document_id = ?`, add it to
   `doc_routes()` in `tests/test_access.py`, and add a mutant to
   `scripts/mutation_check.py`.
3. **404** when the caller has no access at all; 403 only when they can
   already see the document.
4. Every state change writes its audit row inside the same `tx()`. Every
   refusal writes a `denied` row. Never UPDATE or DELETE `audit_logs`.
5. No caching of permissions. Revocation takes effect on the next request.
6. Every form goes through `only_keys()` and carries `csrf_token`.

Before saying something is done: `pytest` passes and
`python scripts/mutation_check.py` kills every mutant.
