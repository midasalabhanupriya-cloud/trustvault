"""Tamper-evident audit trail.

Every row stores prev_hash (the hash of the row before it) and
    hash = HMAC-SHA256(audit_key, prev_hash || canonical(row))

1. The application never UPDATEs or DELETEs audit rows, and database
   triggers abort any attempt.
2. Someone with raw write access to the database can drop the triggers, but
   cannot recompute valid hashes without the audit key, which lives in the
   environment. Editing, deleting or re-ordering a row breaks the chain and
   verify() reports the first bad seq.
3. Deleting the newest rows does not break the chain by itself, so every
   append also prints the new head (seq + hash) to stdout as a JSON line.
   The hosting platform's log store keeps those; compare the latest one with
   verify(expected_seq, expected_hash).

Callers must append inside the same tx() as the change being recorded.
"""
import hashlib
import hmac
import json
import sys
from datetime import datetime, timezone

GENESIS_HASH = "0" * 64
FIELDS = ("seq", "created_at", "user_id", "username", "action", "outcome",
          "document_id", "target_user_id", "ip", "details")


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _canonical(row):
    return json.dumps([row[f] for f in FIELDS], separators=(",", ":"))


def _hash(key, prev_hash, row):
    mac = hmac.new(key, digestmod=hashlib.sha256)
    mac.update(prev_hash.encode())
    mac.update(b"|")
    mac.update(_canonical(row).encode())
    return mac.hexdigest()


def append(db, key, *, action, outcome="success", user_id=None, username=None,
           document_id=None, target_user_id=None, ip=None, details="",
           head_sink=None):
    """Append one row. Must run inside tx(db)."""
    if not db.in_transaction:
        raise RuntimeError("audit.append must run inside tx()")
    last = db.execute(
        "SELECT seq, hash FROM audit_logs ORDER BY seq DESC LIMIT 1"
    ).fetchone()
    prev_seq, prev_hash = (last["seq"], last["hash"]) if last else (0, GENESIS_HASH)
    row = {
        "seq": prev_seq + 1,
        "created_at": now_iso(),
        "user_id": user_id,
        "username": username,
        "action": action,
        "outcome": outcome,
        "document_id": document_id,
        "target_user_id": target_user_id,
        "ip": ip,
        "details": str(details)[:500],
    }
    row_hash = _hash(key, prev_hash, row)
    db.execute(
        f"""INSERT INTO audit_logs ({", ".join(FIELDS)}, prev_hash, hash)
            VALUES ({", ".join("?" * len(FIELDS))}, ?, ?)""",
        [row[f] for f in FIELDS] + [prev_hash, row_hash],
    )
    (head_sink or print_head)({"seq": row["seq"], "hash": row_hash,
                               "at": row["created_at"]})
    return row["seq"]


def print_head(head):
    print(json.dumps({"type": "audit_head", **head}), file=sys.stdout, flush=True)


def verify(db, key, expected_seq=None, expected_hash=None):
    """Walk the whole chain. Returns dict(ok, count, head_seq, head_hash,
    first_bad_seq, reason)."""
    prev_hash, expected_next, count = GENESIS_HASH, 1, 0
    seen = {}
    for row in db.execute("SELECT * FROM audit_logs ORDER BY seq"):
        seq = row["seq"]
        if seq != expected_next:
            return _bad(count, expected_next, f"missing row(s) before seq {seq}")
        if row["prev_hash"] != prev_hash:
            return _bad(count, seq, "prev_hash does not match previous row")
        if not hmac.compare_digest(row["hash"], _hash(key, prev_hash, row)):
            return _bad(count, seq, "row contents do not match its hash")
        prev_hash, expected_next, count = row["hash"], seq + 1, count + 1
        if expected_seq is not None and seq == expected_seq:
            seen[seq] = row["hash"]
    if expected_seq is not None:
        if expected_seq not in seen:
            return _bad(count, expected_seq,
                        "recorded head is missing: newest rows were deleted")
        if not hmac.compare_digest(seen[expected_seq], expected_hash or ""):
            return _bad(count, expected_seq, "recorded head hash does not match")
    return {"ok": True, "count": count, "head_seq": expected_next - 1,
            "head_hash": prev_hash, "first_bad_seq": None, "reason": None}


def _bad(count, seq, reason):
    return {"ok": False, "count": count, "head_seq": None, "head_hash": None,
            "first_bad_seq": seq, "reason": reason}
