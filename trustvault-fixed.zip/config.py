"""Configuration and keys.

Keys come from the environment in production. In development, missing keys
are generated once and saved in the data directory so every worker shares
them. Keeping the master key next to the data defeats encryption at rest,
so production refuses to start without real keys.
"""
import os
import secrets


def is_production():
    return os.environ.get("TRUSTVAULT_ENV") == "production"


def _persisted(data_dir, name):
    path = os.path.join(data_dir, name)
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(secrets.token_hex(32))
    except FileExistsError:
        pass
    with open(path) as f:
        return f.read().strip()


def load_key(env_name, data_dir, filename, hex_bytes=None):
    value = os.environ.get(env_name)
    if not value:
        if is_production():
            raise RuntimeError(f"{env_name} must be set when TRUSTVAULT_ENV=production")
        value = _persisted(data_dir, filename)
    if hex_bytes is not None:
        try:
            raw = bytes.fromhex(value)
        except ValueError:
            raw = b""
        if len(raw) != hex_bytes:
            raise RuntimeError(f"{env_name} must be {hex_bytes * 2} hex characters")
        return raw
    return value
