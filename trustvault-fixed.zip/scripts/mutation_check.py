"""Remove each security check in turn and confirm the test suite fails.

    python scripts/mutation_check.py            # all mutants
    python scripts/mutation_check.py M07 M12    # selected ones

Each mutant is applied to a temporary copy of the repository, so the
working tree is never modified. A mutant that "survives" (tests still pass)
means that check is not really tested.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

MUTANTS = [
    ("M01", "editors may share/revoke", "authz.py",
     '"share": "owner",', '"share": "edit",'),
    ("M02", "readers may download old versions", "authz.py",
     '"download_version": "edit",', '"download_version": "read",'),
    ("M03", "readers may upload versions", "authz.py",
     '"upload_version": "edit",', '"upload_version": "read",'),
    ("M04", "readers may edit details", "authz.py",
     '"update_metadata": "edit",', '"update_metadata": "read",'),
    ("M05", "editors may delete", "authz.py",
     '"delete": "owner",', '"delete": "edit",'),
    ("M06", "readers see activity", "authz.py",
     '"view_activity": "owner",', '"view_activity": "read",'),
    ("M07", "403 instead of 404 reveals existence", "authz.py",
     'if doc is None or doc["level"] is None:\n        return None, 404',
     'if doc is None or doc["level"] is None:\n        return None, 403'),
    ("M08", "expired grants still work", "authz.py",
     "AND (p.expires_at IS NULL OR p.expires_at > :now)", ""),
    ("M10", "trashed documents stay reachable", "authz.py",
     'if action not in TRASH_ACTIONS or doc["level"] != "owner":',
     'if action in TRASH_ACTIONS and doc["level"] != "owner":'),
    ("M11", "refusals are not audited", "authz.py",
     '        audit_event(action, outcome="denied", document_id=document_id,\n'
     '                    details=f"status {status}")', "        pass"),
    ("M12", "version id not bound to document", "app.py",
     '"SELECT * FROM document_versions WHERE id = ? AND document_id = ?",\n'
     '            (version_id, document_id)',
     '"SELECT * FROM document_versions WHERE id = ? AND ? > 0",\n'
     '            (version_id, document_id)'),
    ("M13", "revoke not bound to document", "app.py",
     '"DELETE FROM permissions WHERE document_id = ? AND user_id = ?"',
     '"DELETE FROM permissions WHERE ? > 0 AND user_id = ?"'),
    ("M14", "no CSRF check", "app.py",
     'if request.method == "POST":\n            expected',
     'if False:\n            expected'),
    ("M15", "old sessions survive password change", "app.py",
     'user["session_version"] == session.get("sv")', "True"),
    ("M16", "deactivated users stay logged in", "app.py",
     'if user and user["active"] and', "if user and"),
    ("M17", "anyone is admin", "app.py",
     'if g.user["role"] != "admin":', "if False:"),
    ("M18", "no login throttling", "app.py",
     "return by_name >= MAX_FAILS_PER_USERNAME or by_ip >= MAX_FAILS_PER_IP",
     "return False"),
    ("M19", "my activity shows everyone's", "app.py",
     '"SELECT * FROM audit_logs WHERE user_id = ? ORDER BY seq DESC LIMIT 200"',
     '"SELECT * FROM audit_logs WHERE ? > 0 ORDER BY seq DESC LIMIT 200"'),
    ("M20", "admin may change own account", "app.py",
     'if user_id == g.user["id"]:', "if False:"),
    ("M21", "audit hash not checked", "audit.py",
     'if not hmac.compare_digest(row["hash"], _hash(key, prev_hash, row)):',
     "if False:"),
    ("M22", "truncation not detected", "audit.py",
     "if expected_seq not in seen:", "if False:"),
    ("M23", "audit append-only trigger missing", "database.py",
     "BEFORE UPDATE ON audit_logs\n    BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;",
     "BEFORE UPDATE ON audit_logs\n    BEGIN SELECT 1; END;"),
    ("M24", "unknown form fields accepted", "validation.py",
     "    if extra:\n        abort(400)", "    pass"),
    ("M25", "file content not checked", "validation.py",
     "elif not any(data.startswith(s) for s in sigs):", "elif False:"),
    ("M26", "files stored in plaintext", "storage.py",
     "f.write(nonce + ciphertext)", "f.write(nonce + data)"),
]


def run(mutant):
    mid, desc, rel, old, new = mutant
    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / "repo"
        shutil.copytree(ROOT, copy, ignore=shutil.ignore_patterns(
            ".git", "instance", "__pycache__", ".pytest_cache", ".venv"))
        path = copy / rel
        text = path.read_text()
        if text.count(old) != 1:
            return mid, desc, "BROKEN (pattern not found exactly once)"
        path.write_text(text.replace(old, new))
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider", "tests"],
            cwd=copy, capture_output=True, text=True)
        return mid, desc, "killed" if result.returncode != 0 else "SURVIVED"


def main(selected):
    mutants = [m for m in MUTANTS if not selected or m[0] in selected]
    failed = False
    for m in mutants:
        mid, desc, outcome = run(m)
        print(f"{mid}  {outcome:<10} {desc}", flush=True)
        failed |= outcome != "killed"
    print("\nAll mutants killed." if not failed else "\nSome mutants survived or broke.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(set(sys.argv[1:])))
