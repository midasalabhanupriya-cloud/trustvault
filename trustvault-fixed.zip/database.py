import sqlite3
from contextlib import contextmanager

from flask import current_app, g

SCHEMA = """
    PRAGMA journal_mode = WAL;

    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user', 'admin')),
        active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0, 1)),
        -- Bumped on password change / deactivation: older sessions stop working.
        session_version INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_id INTEGER NOT NULL REFERENCES users(id),
        title TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        current_version_id INTEGER,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        deleted_at TEXT            -- NULL = live, otherwise in the trash
    );

    -- Every upload is a new version. Files on disk are AES-256-GCM encrypted
    -- with a per-version data key, which is itself encrypted ("wrapped") by
    -- the master key. See storage.py.
    CREATE TABLE IF NOT EXISTS document_versions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
        version_no INTEGER NOT NULL,
        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL,
        size INTEGER NOT NULL,
        sha256 TEXT NOT NULL,
        wrapped_key BLOB NOT NULL,
        uploaded_by INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL,
        UNIQUE(document_id, version_no)
    );

    CREATE TABLE IF NOT EXISTS permissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        permission TEXT NOT NULL CHECK(permission IN ('read', 'edit')),
        expires_at TEXT,           -- NULL = never; ISO-8601 UTC otherwise
        granted_by INTEGER NOT NULL REFERENCES users(id),
        created_at TEXT NOT NULL,
        UNIQUE(document_id, user_id)
    );

    -- Append-only and hash-chained (see audit.py). document_id and
    -- target_user_id are deliberately not foreign keys: refusals for ids that
    -- do not exist, and purged documents, must still be recorded.
    CREATE TABLE IF NOT EXISTS audit_logs (
        seq INTEGER PRIMARY KEY,
        created_at TEXT NOT NULL,
        user_id INTEGER,
        username TEXT,
        action TEXT NOT NULL,
        outcome TEXT NOT NULL CHECK(outcome IN ('success', 'denied', 'failure')),
        document_id INTEGER,
        target_user_id INTEGER,
        ip TEXT,
        details TEXT NOT NULL DEFAULT '',
        prev_hash TEXT NOT NULL,
        hash TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS audit_by_action_time ON audit_logs(action, created_at);
    CREATE INDEX IF NOT EXISTS audit_by_document ON audit_logs(document_id);
    CREATE INDEX IF NOT EXISTS audit_by_user ON audit_logs(user_id);

    CREATE TRIGGER IF NOT EXISTS audit_logs_no_update
    BEFORE UPDATE ON audit_logs
    BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;

    CREATE TRIGGER IF NOT EXISTS audit_logs_no_delete
    BEFORE DELETE ON audit_logs
    BEGIN SELECT RAISE(ABORT, 'audit_logs is append-only'); END;
"""


def connect(path):
    # isolation_level=None: we manage transactions ourselves with tx(), so a
    # write transaction always starts with BEGIN IMMEDIATE (see below).
    db = sqlite3.connect(path, timeout=15, isolation_level=None)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    db.execute("PRAGMA busy_timeout = 15000")
    return db


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DATABASE"])
    return g.db


@contextmanager
def tx(db=None):
    """One write transaction. BEGIN IMMEDIATE takes the write lock up front,
    so two workers can never read the same audit head and fork the chain.
    The audit row for a change must be written inside the same tx()."""
    db = db or get_db()
    db.execute("BEGIN IMMEDIATE")
    try:
        yield db
    except BaseException:
        db.execute("ROLLBACK")
        raise
    db.execute("COMMIT")


def init_db(path):
    db = connect(path)
    db.executescript(SCHEMA)
    db.close()


def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()
