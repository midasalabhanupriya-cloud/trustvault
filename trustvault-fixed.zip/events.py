"""Per-request helpers shared by app.py and authz.py."""
from flask import current_app, g, request

import audit
from database import get_db

now_iso = audit.now_iso


def audit_event(action, outcome="success", *, document_id=None,
                target_user_id=None, details="", user=None):
    """Write an audit row for the current request. Call inside tx()."""
    user = user if user is not None else g.get("user")
    audit.append(
        get_db(), current_app.config["AUDIT_KEY"],
        action=action, outcome=outcome,
        user_id=user["id"] if user else None,
        username=user["username"] if user else None,
        document_id=document_id, target_user_id=target_user_id,
        ip=request.remote_addr, details=details,
        head_sink=current_app.config.get("AUDIT_HEAD_SINK"),
    )


def storage():
    return current_app.extensions["trustvault_storage"]
