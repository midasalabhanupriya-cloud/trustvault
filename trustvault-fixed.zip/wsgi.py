"""Entry point for gunicorn:  gunicorn -w 4 wsgi:app"""
from app import create_app

app = create_app()
