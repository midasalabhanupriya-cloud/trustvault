"""Security alerts for the admin console, computed from the audit log."""
from datetime import datetime, timedelta, timezone

import audit

SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2}


def compute_alerts(db, audit_key, now=None):
    now = now or datetime.now(timezone.utc)
    hour_ago = (now - timedelta(hours=1)).isoformat(timespec="seconds")
    day_ago = (now - timedelta(days=1)).isoformat(timespec="seconds")
    alerts = []

    def add(severity, kind, message):
        alerts.append({"severity": severity, "kind": kind, "message": message})

    check = audit.verify(db, audit_key)
    if not check["ok"]:
        add("critical", "audit_tamper",
            f"Audit chain broken at seq {check['first_bad_seq']}: {check['reason']}")

    for r in db.execute(
            """SELECT username, COUNT(*) n, COUNT(DISTINCT document_id) docs
               FROM audit_logs WHERE outcome = 'denied' AND user_id IS NOT NULL
                 AND created_at > ? GROUP BY user_id HAVING n >= 5""", (hour_ago,)):
        add("high", "access_probing",
            f"{r['username']} was refused {r['n']} times in the last hour "
            f"across {r['docs']} document id(s)")

    for r in db.execute(
            """SELECT username, COUNT(*) n FROM audit_logs
               WHERE action = 'login' AND outcome IN ('failure', 'denied')
                 AND created_at > ? GROUP BY username HAVING n >= 5""", (hour_ago,)):
        add("medium", "failed_logins",
            f"{r['n']} failed sign-ins for '{r['username']}' in the last hour")

    for r in db.execute(
            """SELECT ip, COUNT(*) n, COUNT(DISTINCT username) accounts FROM audit_logs
               WHERE action = 'login' AND outcome = 'failure' AND created_at > ?
               GROUP BY ip HAVING accounts >= 3""", (hour_ago,)):
        add("high", "password_spraying",
            f"IP {r['ip']} failed sign-in against {r['accounts']} different "
            f"accounts in the last hour")

    for r in db.execute(
            """SELECT username, COUNT(*) n, COUNT(DISTINCT document_id) docs
               FROM audit_logs WHERE action IN ('download', 'download_version')
                 AND outcome = 'success' AND created_at > ?
               GROUP BY user_id HAVING docs >= 10""", (hour_ago,)):
        add("high", "bulk_download",
            f"{r['username']} downloaded {r['docs']} distinct documents "
            f"({r['n']} downloads) in the last hour")

    for r in db.execute(
            """SELECT username, COUNT(*) n FROM audit_logs
               WHERE action = 'share' AND outcome = 'success' AND created_at > ?
               GROUP BY user_id HAVING n >= 10""", (hour_ago,)):
        add("medium", "mass_sharing",
            f"{r['username']} created or changed {r['n']} grants in the last hour")

    for r in db.execute(
            """SELECT username, details, created_at FROM audit_logs
               WHERE action = 'admin_user_change' AND created_at > ?
               ORDER BY seq DESC LIMIT 20""", (day_ago,)):
        add("medium", "privileged_change",
            f"{r['username']} changed {r['details']} at {r['created_at']}")

    alerts.sort(key=lambda a: SEVERITY_ORDER[a["severity"]])
    return alerts
