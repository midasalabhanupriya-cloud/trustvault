"""Demo data.  python seed.py   (or TRUSTVAULT_AUTO_SEED=1 on an empty DB)

Passwords default to the ones below; override them all with
TRUSTVAULT_SEED_PASSWORD.
"""
import os

from werkzeug.security import generate_password_hash

import audit
from database import connect, tx

USERS = [
    # username, role, password
    ("admin", "admin", "Admin-Demo-2026!"),
    ("olivia", "user", "Owner-Demo-2026!"),
    ("oscar", "user", "Owner-Demo-2026!"),
    ("vera", "user", "Viewer-Demo-2026!"),
    ("victor", "user", "Viewer-Demo-2026!"),
    ("pat", "user", "Viewer-Demo-2026!"),
]

DOCS = [
    # owner, title, file name, body, [(user, permission)]
    ("olivia", "Salary letter - Vera", "salary-vera.txt",
     "Dear Vera,\nYour salary from 1 January is 52,000.\n", [("vera", "read")]),
    ("olivia", "Salary letter - Victor", "salary-victor.txt",
     "Dear Victor,\nYour salary from 1 January is 49,500.\n", [("victor", "read")]),
    ("olivia", "HR handbook", "handbook.txt",
     "HR handbook\n\n1. Holidays\n2. Expenses\n", [("vera", "read"), ("victor", "edit")]),
    ("oscar", "Partner contract", "partner-contract.txt",
     "Contract between the company and Partner Ltd.\n", [("pat", "read")]),
    ("oscar", "Litigation memo", "litigation-memo.txt",
     "Privileged and confidential.\n", []),
]


def seed(app):
    db = connect(app.config["DATABASE"])
    store = app.extensions["trustvault_storage"]
    key = app.config["AUDIT_KEY"]
    sink = app.config.get("AUDIT_HEAD_SINK")
    override = os.environ.get("TRUSTVAULT_SEED_PASSWORD")
    now = audit.now_iso()
    ids = {}
    with tx(db):
        for username, role, password in USERS:
            cur = db.execute(
                "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
                (username, generate_password_hash(override or password), role, now))
            ids[username] = cur.lastrowid
            audit.append(db, key, action="seed_user", username=username,
                         user_id=cur.lastrowid, head_sink=sink)
        for owner, title, filename, body, grants in DOCS:
            cur = db.execute(
                "INSERT INTO documents (owner_id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
                (ids[owner], title, now, now))
            doc_id = cur.lastrowid
            meta = store.put(body.encode())
            v = db.execute(
                """INSERT INTO document_versions (document_id, version_no, original_name,
                   stored_name, size, sha256, wrapped_key, uploaded_by, created_at)
                   VALUES (?, 1, ?, ?, ?, ?, ?, ?, ?)""",
                (doc_id, filename, meta["stored_name"], meta["size"], meta["sha256"],
                 meta["wrapped_key"], ids[owner], now))
            db.execute("UPDATE documents SET current_version_id = ? WHERE id = ?",
                       (v.lastrowid, doc_id))
            for user, permission in grants:
                db.execute(
                    """INSERT INTO permissions (document_id, user_id, permission,
                       granted_by, created_at) VALUES (?, ?, ?, ?, ?)""",
                    (doc_id, ids[user], permission, ids[owner], now))
            audit.append(db, key, action="seed_document", user_id=ids[owner],
                         username=owner, document_id=doc_id, details=title, head_sink=sink)
    db.close()


def seed_if_empty(app):
    db = connect(app.config["DATABASE"])
    empty = db.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0
    db.close()
    if empty:
        try:
            seed(app)
        except Exception:  # another worker seeded first
            pass


if __name__ == "__main__":
    from app import create_app
    application = create_app()
    db = connect(application.config["DATABASE"])
    has_users = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    db.close()
    if has_users:
        raise SystemExit("Database already has users; seed only an empty database.")
    seed(application)
    print("Seeded demo users:", ", ".join(u for u, _, _ in USERS))
