"""Authorisation. The ONLY place that decides who may do what to a document.

Routes call gate(); nothing else re-implements the check. The dashboard
listing reuses ACCESS_LEVEL_SQL rather than writing its own query.

Admins get no document access from their role: an admin sees a document
only if they own it or it was shared with them, like anyone else.
"""
from flask import abort, g

from database import get_db, tx
from events import audit_event, now_iso

LEVELS = {None: 0, "read": 1, "edit": 2, "owner": 3}

REQUIRED_LEVEL = {
    "view": "read",              # metadata page
    "download": "read",          # current version
    "list_versions": "edit",
    "download_version": "edit",  # any older version
    "upload_version": "edit",
    "update_metadata": "edit",
    "share": "owner",            # create / change / revoke grants
    "view_activity": "owner",
    "delete": "owner",           # move to trash
    "restore": "owner",
    "purge": "owner",
}

# Actions that apply to documents in the trash. Every other action needs a
# live document; a trashed document is "not found" for them, even for its
# owner, so the trash is invisible to everyone else.
TRASH_ACTIONS = {"restore", "purge"}

# Caller's level on document d. Parameters: :uid, :now. Grants past their
# expires_at count as no grant. (Whether the caller's account is active is
# decided once, in load_user() in app.py: an inactive user has no session.)
ACCESS_LEVEL_SQL = """
    CASE
      WHEN d.owner_id = :uid THEN 'owner'
      ELSE (SELECT p.permission FROM permissions p
             WHERE p.document_id = d.id AND p.user_id = :uid
               AND (p.expires_at IS NULL OR p.expires_at > :now))
    END"""


def access_level(db, user_id, document_id, now):
    row = db.execute(
        f"SELECT d.*, {ACCESS_LEVEL_SQL} AS level FROM documents d WHERE d.id = :doc",
        {"uid": user_id, "now": now, "doc": document_id},
    ).fetchone()
    return row


def decide(db, user_id, document_id, action, now):
    """Returns (document_row_or_None, status): status is 'ok', 404, 403 or 409."""
    doc = access_level(db, user_id, document_id, now)
    if doc is None or doc["level"] is None:
        return None, 404
    enough = LEVELS[doc["level"]] >= LEVELS[REQUIRED_LEVEL[action]]
    in_trash = doc["deleted_at"] is not None
    if in_trash:
        # The trash is visible only to the owner, and only for restore/purge.
        if action not in TRASH_ACTIONS or doc["level"] != "owner":
            return None, 404
        return doc, "ok"
    if not enough:
        return doc, 403
    if action in TRASH_ACTIONS:
        return doc, 409  # restore/purge on a live document
    return doc, "ok"


def gate(document_id, action):
    """Return the document if the current user may perform `action`.

    No access at all -> 404 (identical to a document that does not exist).
    Can see it but lacks the level -> 403. Every refusal is audited.
    """
    db = get_db()
    doc, status = decide(db, g.user["id"], document_id, action, now_iso())
    if status == "ok":
        return doc
    with tx(db):
        audit_event(action, outcome="denied", document_id=document_id,
                    details=f"status {status}")
    abort(status)
