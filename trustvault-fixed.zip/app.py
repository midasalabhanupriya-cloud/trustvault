import hmac
import io
import os
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import (
    Flask, abort, flash, g, redirect, render_template, request, send_file,
    session, url_for,
)
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.security import check_password_hash, generate_password_hash

import audit
from alerts import compute_alerts
from authz import ACCESS_LEVEL_SQL, REQUIRED_LEVEL, gate
from config import is_production, load_key
from database import close_db, get_db, init_db, tx
from events import audit_event, now_iso, storage
from storage import Storage
from validation import check_upload, clean_text, only_keys

LOGIN_WINDOW = timedelta(minutes=15)
MAX_FAILS_PER_USERNAME = 5
MAX_FAILS_PER_IP = 20
MIN_PASSWORD = 8


def iso_in(**delta):
    return (datetime.now(timezone.utc) + timedelta(**delta)).isoformat(timespec="seconds")


# --------------------------------------------------------------------------
# Request helpers
# --------------------------------------------------------------------------

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            flash("Please log in first.")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if g.user["role"] != "admin":
            with tx():
                audit_event("admin_access", "denied", details=request.path)
            abort(404)
        return view(*args, **kwargs)
    return wrapped


def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


def start_session(user):
    session.clear()
    session["user_id"] = user["id"]
    session["sv"] = user["session_version"]
    session.permanent = True


def throttled(db, username, ip):
    since = (datetime.now(timezone.utc) - LOGIN_WINDOW).isoformat(timespec="seconds")
    by_name = db.execute(
        """SELECT COUNT(*) FROM audit_logs WHERE action = 'login'
           AND outcome = 'failure' AND username = ? AND created_at > ?""",
        (username, since)).fetchone()[0]
    by_ip = db.execute(
        """SELECT COUNT(*) FROM audit_logs WHERE action = 'login'
           AND outcome = 'failure' AND ip = ? AND created_at > ?""",
        (ip, since)).fetchone()[0]
    return by_name >= MAX_FAILS_PER_USERNAME or by_ip >= MAX_FAILS_PER_IP


def get_user_by_name(db, username):
    return db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()


def store_version(db, document_id, original_name, data):
    """Encrypt `data` and add it as the next version. Call inside tx()."""
    meta = storage().put(data)
    try:
        number = db.execute(
            "SELECT COALESCE(MAX(version_no), 0) + 1 FROM document_versions "
            "WHERE document_id = ?", (document_id,)).fetchone()[0]
        cur = db.execute(
            """INSERT INTO document_versions
               (document_id, version_no, original_name, stored_name, size,
                sha256, wrapped_key, uploaded_by, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (document_id, number, original_name, meta["stored_name"],
             meta["size"], meta["sha256"], meta["wrapped_key"], g.user["id"],
             now_iso()))
        db.execute(
            "UPDATE documents SET current_version_id = ?, updated_at = ? WHERE id = ?",
            (cur.lastrowid, now_iso(), document_id))
    except BaseException:
        storage().remove(meta["stored_name"])
        raise
    return number, meta


def send_version(version):
    data = storage().get(version["stored_name"], version["wrapped_key"])
    return send_file(io.BytesIO(data), as_attachment=True,
                     download_name=version["original_name"],
                     mimetype="application/octet-stream")


# --------------------------------------------------------------------------
# Application
# --------------------------------------------------------------------------

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    data_dir = os.environ.get("TRUSTVAULT_DATA_DIR", app.instance_path)
    production = is_production()

    app.config.update(
        DATABASE=os.path.join(data_dir, "trustvault.db"),
        UPLOAD_FOLDER=os.path.join(data_dir, "blobs"),
        MAX_CONTENT_LENGTH=10 * 1024 * 1024,
        PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=production or os.environ.get("SESSION_COOKIE_SECURE") == "1",
    )
    if test_config:
        app.config.update(test_config)

    os.makedirs(data_dir, exist_ok=True)
    os.makedirs(os.path.dirname(app.config["DATABASE"]), exist_ok=True)
    if not app.config.get("SECRET_KEY"):
        app.secret_key = load_key("SECRET_KEY", data_dir, "secret_key")
    if not app.config.get("MASTER_KEY"):
        app.config["MASTER_KEY"] = load_key("TRUSTVAULT_MASTER_KEY", data_dir, "master_key", 32)
    if not app.config.get("AUDIT_KEY"):
        app.config["AUDIT_KEY"] = load_key("TRUSTVAULT_AUDIT_KEY", data_dir, "audit_key", 32)
    if app.config["MASTER_KEY"] == app.config["AUDIT_KEY"]:
        raise RuntimeError("TRUSTVAULT_MASTER_KEY and TRUSTVAULT_AUDIT_KEY must differ")

    if os.environ.get("TRUSTVAULT_TRUST_PROXY") == "1":
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)

    init_db(app.config["DATABASE"])
    app.extensions["trustvault_storage"] = Storage(
        app.config["UPLOAD_FOLDER"], app.config["MASTER_KEY"])
    app.teardown_appcontext(close_db)
    app.jinja_env.globals.update(csrf_token=csrf_token, required=REQUIRED_LEVEL)
    app.jinja_env.filters["filesize"] = lambda n: (
        f"{n} bytes" if n < 1024 else f"{n / 1024:.1f} KB" if n < 1024 ** 2
        else f"{n / 1024 ** 2:.1f} MB")

    if os.environ.get("TRUSTVAULT_AUTO_SEED") == "1":
        from seed import seed_if_empty
        seed_if_empty(app)

    # ---------------------------------------------------------------- hooks

    @app.before_request
    def load_user():
        g.user = None
        uid = session.get("user_id")
        if uid is None:
            return
        user = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        # Checked on every request: deactivation and password changes take
        # effect immediately, there is no cached permission state.
        if user and user["active"] and user["session_version"] == session.get("sv"):
            g.user = user
        else:
            session.clear()

    @app.before_request
    def check_csrf():
        if request.method == "POST":
            expected = session.get("csrf_token")
            sent = request.form.get("csrf_token", "")
            if not expected or not hmac.compare_digest(expected, sent):
                abort(400)

    @app.after_request
    def security_headers(response):
        h = response.headers
        h["X-Content-Type-Options"] = "nosniff"
        h["X-Frame-Options"] = "DENY"
        h["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'none'; object-src 'none'; "
            "frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
        h["Referrer-Policy"] = "same-origin"
        if g.get("user"):
            h["Cache-Control"] = "no-store"
        if production:
            h["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        return response

    # ----------------------------------------------------------------- auth

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            form = only_keys(request.form, {"username", "password"})
            username = form.get("username", "").strip()
            password = form.get("password", "")
            if not (3 <= len(username) <= 40) or not username.isprintable():
                flash("Username must be 3-40 characters.")
                return redirect(url_for("register"))
            if len(password) < MIN_PASSWORD:
                flash(f"Password must be at least {MIN_PASSWORD} characters.")
                return redirect(url_for("register"))
            db = get_db()
            try:
                with tx(db):
                    cur = db.execute(
                        "INSERT INTO users (username, password_hash, created_at) "
                        "VALUES (?, ?, ?)",
                        (username, generate_password_hash(password), now_iso()))
                    audit_event("register", user={"id": cur.lastrowid, "username": username})
            except sqlite3.IntegrityError:
                flash("That username is already taken.")
                return redirect(url_for("register"))
            flash("Account created. Please log in.")
            return redirect(url_for("login"))
        return render_template("login.html", mode="register")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            form = only_keys(request.form, {"username", "password"})
            username = form.get("username", "").strip()[:40]
            password = form.get("password", "")
            db = get_db()

            if throttled(db, username, request.remote_addr):
                with tx(db):
                    audit_event("login", "denied", details="throttled",
                                user={"id": None, "username": username})
                flash("Too many failed attempts. Try again in 15 minutes.")
                return render_template("login.html", mode="login"), 429

            user = get_user_by_name(db, username)
            ok = user is not None and check_password_hash(user["password_hash"], password)
            if not user:
                check_password_hash(DUMMY_HASH, password)  # same timing
            if ok and user["active"]:
                start_session(user)
                with tx(db):
                    audit_event("login", user=user)
                return redirect(url_for("dashboard"))

            with tx(db):
                audit_event("login", "failure",
                            details="inactive account" if ok else "bad credentials",
                            user={"id": user["id"] if user else None,
                                  "username": username})
            flash("Invalid username or password.")
        return render_template("login.html", mode="login")

    @app.route("/logout", methods=["POST"])
    @login_required
    def logout():
        with tx():
            audit_event("logout")
        session.clear()
        return redirect(url_for("index"))

    @app.route("/account", methods=["GET", "POST"])
    @login_required
    def account():
        if request.method == "POST":
            form = only_keys(request.form, {"current_password", "new_password"})
            new = form.get("new_password", "")
            if not check_password_hash(g.user["password_hash"], form.get("current_password", "")):
                with tx():
                    audit_event("password_change", "failure", details="wrong current password")
                flash("Current password is wrong.")
            elif len(new) < MIN_PASSWORD:
                flash(f"New password must be at least {MIN_PASSWORD} characters.")
            else:
                db = get_db()
                with tx(db):
                    db.execute(
                        """UPDATE users SET password_hash = ?,
                           session_version = session_version + 1 WHERE id = ?""",
                        (generate_password_hash(new), g.user["id"]))
                    audit_event("password_change")
                # Every other session for this user is now invalid.
                start_session(db.execute("SELECT * FROM users WHERE id = ?",
                                         (g.user["id"],)).fetchone())
                flash("Password changed. Other sessions have been signed out.")
            return redirect(url_for("account"))
        return render_template("account.html")

    # ------------------------------------------------------------ documents

    @app.route("/dashboard")
    @login_required
    def dashboard():
        db = get_db()
        params = {"uid": g.user["id"], "now": now_iso()}
        documents = db.execute(
            f"""SELECT * FROM (
                  SELECT d.*, {ACCESS_LEVEL_SQL} AS level FROM documents d
                  WHERE d.deleted_at IS NULL)
                WHERE level IS NOT NULL
                ORDER BY updated_at DESC, id DESC""", params).fetchall()
        trash = db.execute(
            f"""SELECT * FROM (
                  SELECT d.*, {ACCESS_LEVEL_SQL} AS level FROM documents d
                  WHERE d.deleted_at IS NOT NULL)
                WHERE level = 'owner' ORDER BY deleted_at DESC""", params).fetchall()
        return render_template("dashboard.html", documents=documents, trash=trash)

    @app.route("/upload", methods=["POST"])
    @login_required
    def upload():
        form = only_keys(request.form, {"title", "description"}, files={"file"})
        checked = check_upload(request.files.get("file"))
        if isinstance(checked, str):
            flash(checked)
            return redirect(url_for("dashboard"))
        name, data = checked
        title = clean_text(form.get("title"), 120) or name
        db = get_db()
        with tx(db):
            cur = db.execute(
                """INSERT INTO documents (owner_id, title, description, created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (g.user["id"], title, clean_text(form.get("description"), 1000),
                 now_iso(), now_iso()))
            doc_id = cur.lastrowid
            store_version(db, doc_id, name, data)
            audit_event("upload", document_id=doc_id, details=name)
        flash("Document uploaded.")
        return redirect(url_for("document", document_id=doc_id))

    @app.route("/documents/<int:document_id>")
    @login_required
    def document(document_id):
        doc = gate(document_id, "view")
        db = get_db()
        versions = grants = None
        if doc["level"] in ("edit", "owner"):
            versions = db.execute(
                """SELECT v.id, v.version_no, v.original_name, v.size, v.sha256,
                          v.created_at, u.username AS uploader
                   FROM document_versions v LEFT JOIN users u ON u.id = v.uploaded_by
                   WHERE v.document_id = ? ORDER BY v.version_no DESC""",
                (document_id,)).fetchall()
        if doc["level"] == "owner":
            grants = db.execute(
                """SELECT p.*, u.username, u.active,
                          (p.expires_at IS NOT NULL AND p.expires_at <= ?) AS expired
                   FROM permissions p JOIN users u ON u.id = p.user_id
                   WHERE p.document_id = ? ORDER BY u.username""",
                (now_iso(), document_id)).fetchall()
        current = db.execute(
            "SELECT original_name, size, version_no, created_at FROM document_versions WHERE id = ?",
            (doc["current_version_id"],)).fetchone()
        owner = db.execute("SELECT username FROM users WHERE id = ?",
                           (doc["owner_id"],)).fetchone()
        return render_template("document.html", doc=doc, current=current,
                               versions=versions, grants=grants,
                               owner=owner["username"])

    @app.route("/documents/<int:document_id>/download")
    @login_required
    def download(document_id):
        doc = gate(document_id, "download")
        db = get_db()
        version = db.execute(
            "SELECT * FROM document_versions WHERE id = ? AND document_id = ?",
            (doc["current_version_id"], document_id)).fetchone()
        with tx(db):
            audit_event("download", document_id=document_id,
                        details=f"v{version['version_no']}")
        return send_version(version)

    @app.route("/documents/<int:document_id>/versions/<int:version_id>/download")
    @login_required
    def download_version(document_id, version_id):
        gate(document_id, "download_version")
        db = get_db()
        version = db.execute(
            "SELECT * FROM document_versions WHERE id = ? AND document_id = ?",
            (version_id, document_id)).fetchone()
        if version is None:
            with tx(db):
                audit_event("download_version", "denied", document_id=document_id,
                            details=f"version {version_id} not in document")
            abort(404)
        with tx(db):
            audit_event("download_version", document_id=document_id,
                        details=f"v{version['version_no']}")
        return send_version(version)

    @app.route("/documents/<int:document_id>/versions", methods=["POST"])
    @login_required
    def upload_version(document_id):
        gate(document_id, "upload_version")
        only_keys(request.form, set(), files={"file"})
        checked = check_upload(request.files.get("file"))
        if isinstance(checked, str):
            flash(checked)
            return redirect(url_for("document", document_id=document_id))
        name, data = checked
        db = get_db()
        with tx(db):
            number, _ = store_version(db, document_id, name, data)
            audit_event("upload_version", document_id=document_id,
                        details=f"v{number}: {name}")
        flash(f"Version {number} uploaded.")
        return redirect(url_for("document", document_id=document_id))

    @app.route("/documents/<int:document_id>/edit", methods=["POST"])
    @login_required
    def update_metadata(document_id):
        doc = gate(document_id, "update_metadata")
        form = only_keys(request.form, {"title", "description"})
        title = clean_text(form.get("title"), 120)
        if not title:
            flash("Title is required.")
            return redirect(url_for("document", document_id=document_id))
        db = get_db()
        with tx(db):
            db.execute(
                "UPDATE documents SET title = ?, description = ?, updated_at = ? WHERE id = ?",
                (title, clean_text(form.get("description"), 1000), now_iso(), document_id))
            audit_event("update_metadata", document_id=document_id,
                        details=f"title: {doc['title']} -> {title}")
        flash("Details saved.")
        return redirect(url_for("document", document_id=document_id))

    @app.route("/documents/<int:document_id>/share", methods=["POST"])
    @login_required
    def share(document_id):
        gate(document_id, "share")
        form = only_keys(request.form, {"username", "permission", "expires_days"})
        permission = form.get("permission", "read")
        if permission not in ("read", "edit"):
            abort(400)
        days = form.get("expires_days", "").strip()
        if days:
            if not days.isdigit() or not 1 <= int(days) <= 365:
                flash("Expiry must be between 1 and 365 days, or blank.")
                return redirect(url_for("document", document_id=document_id))
            expires_at = iso_in(days=int(days))
        else:
            expires_at = None

        db = get_db()
        target = get_user_by_name(db, form.get("username", "").strip())
        if not target or not target["active"] or target["id"] == g.user["id"]:
            flash("No other active user with that username.")
            return redirect(url_for("document", document_id=document_id))

        with tx(db):
            db.execute(
                """INSERT INTO permissions
                   (document_id, user_id, permission, expires_at, granted_by, created_at)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(document_id, user_id) DO UPDATE SET
                     permission = excluded.permission,
                     expires_at = excluded.expires_at,
                     granted_by = excluded.granted_by,
                     created_at = excluded.created_at""",
                (document_id, target["id"], permission, expires_at,
                 g.user["id"], now_iso()))
            audit_event("share", document_id=document_id, target_user_id=target["id"],
                        details=f"{target['username']}: {permission}"
                                + (f" until {expires_at}" if expires_at else ""))
        flash(f"Shared with {target['username']} ({permission}).")
        return redirect(url_for("document", document_id=document_id))

    @app.route("/documents/<int:document_id>/revoke/<int:target_id>", methods=["POST"])
    @login_required
    def revoke(document_id, target_id):
        gate(document_id, "share")
        only_keys(request.form, set())
        db = get_db()
        with tx(db):
            cur = db.execute(
                "DELETE FROM permissions WHERE document_id = ? AND user_id = ?",
                (document_id, target_id))
            if cur.rowcount:
                audit_event("revoke", document_id=document_id, target_user_id=target_id)
        flash("Access revoked." if cur.rowcount else "Nothing to revoke.")
        return redirect(url_for("document", document_id=document_id))

    @app.route("/documents/<int:document_id>/activity")
    @login_required
    def activity(document_id):
        doc = gate(document_id, "view_activity")
        logs = get_db().execute(
            "SELECT * FROM audit_logs WHERE document_id = ? ORDER BY seq DESC LIMIT 500",
            (document_id,)).fetchall()
        return render_template("audit.html", logs=logs, doc=doc,
                               heading=f"Activity: {doc['title']}")

    @app.route("/documents/<int:document_id>/delete", methods=["POST"])
    @login_required
    def delete(document_id):
        gate(document_id, "delete")
        only_keys(request.form, set())
        db = get_db()
        with tx(db):
            db.execute("UPDATE documents SET deleted_at = ? WHERE id = ?",
                       (now_iso(), document_id))
            audit_event("delete", document_id=document_id)
        flash("Moved to trash. Shared users can no longer open it.")
        return redirect(url_for("dashboard"))

    @app.route("/documents/<int:document_id>/restore", methods=["POST"])
    @login_required
    def restore(document_id):
        gate(document_id, "restore")
        only_keys(request.form, set())
        db = get_db()
        with tx(db):
            db.execute("UPDATE documents SET deleted_at = NULL WHERE id = ?", (document_id,))
            audit_event("restore", document_id=document_id)
        flash("Document restored.")
        return redirect(url_for("document", document_id=document_id))

    @app.route("/documents/<int:document_id>/purge", methods=["POST"])
    @login_required
    def purge(document_id):
        gate(document_id, "purge")
        only_keys(request.form, set())
        db = get_db()
        stored = [r["stored_name"] for r in db.execute(
            "SELECT stored_name FROM document_versions WHERE document_id = ?",
            (document_id,))]
        with tx(db):
            db.execute("DELETE FROM documents WHERE id = ?", (document_id,))
            audit_event("purge", document_id=document_id,
                        details=f"{len(stored)} version(s) destroyed")
        for name in stored:
            storage().remove(name)
        flash("Document permanently deleted.")
        return redirect(url_for("dashboard"))

    @app.route("/audit")
    @login_required
    def my_activity():
        logs = get_db().execute(
            "SELECT * FROM audit_logs WHERE user_id = ? ORDER BY seq DESC LIMIT 200",
            (g.user["id"],)).fetchall()
        return render_template("audit.html", logs=logs, heading="My activity")

    # ---------------------------------------------------------------- admin

    @app.route("/admin")
    @admin_required
    def admin():
        db = get_db()
        users = db.execute(
            """SELECT u.id, u.username, u.role, u.active, u.created_at,
                      (SELECT COUNT(*) FROM documents d WHERE d.owner_id = u.id) AS docs
               FROM users u ORDER BY u.username""").fetchall()
        return render_template("admin.html", users=users,
                               alerts=compute_alerts(db, app.config["AUDIT_KEY"]))

    @app.route("/admin/users/<int:user_id>", methods=["POST"])
    @admin_required
    def admin_update_user(user_id):
        form = only_keys(request.form, {"active", "role"})
        if user_id == g.user["id"]:
            flash("You cannot change your own account here.")
            return redirect(url_for("admin"))
        db = get_db()
        target = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        if target is None:
            abort(404)
        changes = []
        with tx(db):
            if "active" in form and form["active"] in ("0", "1"):
                active = int(form["active"])
                if active != target["active"]:
                    db.execute(
                        """UPDATE users SET active = ?,
                           session_version = session_version + 1 WHERE id = ?""",
                        (active, user_id))
                    changes.append("activated" if active else "deactivated")
            if "role" in form and form["role"] in ("user", "admin"):
                if form["role"] != target["role"]:
                    db.execute(
                        """UPDATE users SET role = ?,
                           session_version = session_version + 1 WHERE id = ?""",
                        (form["role"], user_id))
                    changes.append(f"role -> {form['role']}")
            for change in changes:
                audit_event("admin_user_change", target_user_id=user_id,
                            details=f"{target['username']}: {change}")
        flash(f"{target['username']}: {', '.join(changes) or 'no change'}.")
        return redirect(url_for("admin"))

    @app.route("/admin/audit")
    @admin_required
    def admin_audit():
        args = request.args
        where, params = [], []
        if args.get("username"):
            where.append("username = ?")
            params.append(args["username"])
        if args.get("action"):
            where.append("action = ?")
            params.append(args["action"])
        if args.get("outcome") in ("success", "denied", "failure"):
            where.append("outcome = ?")
            params.append(args["outcome"])
        if args.get("document_id", "").isdigit():
            where.append("document_id = ?")
            params.append(int(args["document_id"]))
        sql = "SELECT * FROM audit_logs"
        if where:
            sql += " WHERE " + " AND ".join(where)
        logs = get_db().execute(sql + " ORDER BY seq DESC LIMIT 500", params).fetchall()

        verification = None
        if "verify" in args:
            seq = args.get("seq", "").strip()
            verification = audit.verify(
                get_db(), app.config["AUDIT_KEY"],
                int(seq) if seq.isdigit() else None,
                args.get("hash", "").strip() or None)
        return render_template("audit.html", logs=logs, heading="Audit log (all users)",
                               admin=True, filters=args, verification=verification)

    # --------------------------------------------------------------- errors

    @app.errorhandler(400)
    def bad_request(error):
        return render_template("error.html", message="Bad request."), 400

    @app.errorhandler(403)
    def forbidden(error):
        return render_template("error.html", message="You do not have permission to do that."), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template("error.html", message="Not found."), 404

    @app.errorhandler(409)
    def conflict(error):
        return render_template("error.html", message="That document is not in the trash."), 409

    @app.errorhandler(413)
    def too_large(error):
        return render_template("error.html", message="File too large. Maximum size is 10 MB."), 413

    return app


DUMMY_HASH = generate_password_hash(secrets.token_hex(16))

if __name__ == "__main__":
    create_app().run(debug=os.environ.get("FLASK_DEBUG") == "1")
