"""Encrypted file storage (envelope encryption).

Each version gets a fresh random 256-bit data key. The file is encrypted
with AES-256-GCM under that key; the data key is encrypted (wrapped) with
the master key and stored in the database. The stored file name is bound as
associated data, so swapping ciphertexts between versions fails to decrypt.

Files on disk:  nonce(12) || ciphertext+tag
wrapped_key:    nonce(12) || AESGCM(master, data_key, aad=stored_name)
"""
import hashlib
import os
import secrets

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


class Storage:
    def __init__(self, folder, master_key):
        self.folder = folder
        self.master = AESGCM(master_key)
        os.makedirs(folder, exist_ok=True)

    def _path(self, stored_name):
        if not stored_name or "/" in stored_name or stored_name.startswith("."):
            raise ValueError("bad stored name")
        return os.path.join(self.folder, stored_name)

    def put(self, data):
        """Encrypt and store `data`. Returns dict for document_versions."""
        stored_name = secrets.token_hex(16) + ".bin"
        data_key = AESGCM.generate_key(bit_length=256)
        nonce = os.urandom(12)
        aad = stored_name.encode()
        ciphertext = AESGCM(data_key).encrypt(nonce, data, aad)
        wrap_nonce = os.urandom(12)
        wrapped = wrap_nonce + self.master.encrypt(wrap_nonce, data_key, aad)
        with open(self._path(stored_name), "xb") as f:
            f.write(nonce + ciphertext)
        return {
            "stored_name": stored_name,
            "wrapped_key": wrapped,
            "size": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        }

    def get(self, stored_name, wrapped_key):
        aad = stored_name.encode()
        data_key = self.master.decrypt(wrapped_key[:12], wrapped_key[12:], aad)
        with open(self._path(stored_name), "rb") as f:
            blob = f.read()
        return AESGCM(data_key).decrypt(blob[:12], blob[12:], aad)

    def remove(self, stored_name):
        try:
            os.remove(self._path(stored_name))
        except FileNotFoundError:
            pass
