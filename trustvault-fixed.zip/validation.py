"""Input validation."""
from flask import abort
from werkzeug.utils import secure_filename

# Extension -> accepted leading bytes. The file must look like what its
# name says, so a renamed HTML/script file is refused.
SIGNATURES = {
    "pdf": [b"%PDF-"],
    "png": [b"\x89PNG\r\n\x1a\n"],
    "jpg": [b"\xff\xd8\xff"],
    "jpeg": [b"\xff\xd8\xff"],
    "docx": [b"PK\x03\x04"],
    "doc": [b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"],
    "txt": None,  # checked as UTF-8 text below
}
ALLOWED = ", ".join(sorted(SIGNATURES))


def only_keys(form, allowed, files=()):
    """Unknown form fields are a 400, so typos and tampering are not
    silently ignored."""
    extra = set(form.keys()) - set(allowed) - {"csrf_token"}
    from flask import request
    extra |= set(request.files.keys()) - set(files)
    if extra:
        abort(400)
    return form


def clean_text(value, limit):
    value = (value or "").strip()
    value = "".join(ch for ch in value if ch.isprintable() or ch == "\n")
    return value[:limit]


def check_upload(file):
    """Return (safe_name, bytes), or an error message string."""
    if not file or not file.filename:
        return "Choose a file to upload."
    name = secure_filename(file.filename)
    ext = name.rsplit(".", 1)[1].lower() if "." in name else ""
    if ext not in SIGNATURES:
        return f"File type not allowed. Allowed: {ALLOWED}."
    data = file.read()
    if not data:
        return "The file is empty."
    sigs = SIGNATURES[ext]
    if sigs is None:
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            return "A .txt file must be UTF-8 text."
        if "\x00" in text:
            return "A .txt file must be UTF-8 text."
    elif not any(data.startswith(s) for s in sigs):
        return f"The file content does not match a .{ext} file."
    return name, data
